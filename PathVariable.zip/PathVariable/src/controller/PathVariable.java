/*package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import model.Customer;

@Controller
public class PathVariable {
	
	@RequestMapping("/customer/{cId}/{cName}")
	public String empRequest(@PathVariable("cId") int id,@PathVariable("cName") String name,Model model){
		System.out.println(id);
		System.out.println(name);
		model.addAttribute("cId",id);
		model.addAttribute("cName",name);
		
		return "welcome";
	}

}*/