package bean;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Cart {

	int cId;
	String cName;
	
	@Autowired
	@Qualifier("item")
	//@Resource(name="item")
	Item item;

	public Cart() {
		
	}

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Item getItem() {
		return item;
	}	
}
