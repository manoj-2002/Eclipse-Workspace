package bean;

public class Item {

	int iId;
	String iName;
	int price;
	public Item() {
		
	}
	public int getiId() {
		return iId;
	}
	public void setiId(int iId) {
		this.iId = iId;
	}
	public String getiName() {
		return iName;
	}
	public void setiName(String iName) {
		this.iName = iName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Item [iId=" + iId + ", iName=" + iName + ", price=" + price + "]";
	}
	
	
	
}
