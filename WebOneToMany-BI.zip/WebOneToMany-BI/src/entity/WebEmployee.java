package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="task_employee")
public class WebEmployee
  {
	@Id
	@Column
	int empId;
	@Column(length=20)
	String empName;
	@OneToMany(cascade= {CascadeType.ALL})
	@JoinTable(name="task_web_address", joinColumns=@JoinColumn(name="empId"),inverseJoinColumns=@JoinColumn(name="aId"))
	Set<WebAddress> addressSet=new HashSet<>();
	public WebEmployee() {
		
	}
	public WebEmployee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}
	public WebEmployee(int empId, String empName, Set<WebAddress> addressSet) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.addressSet = addressSet;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Set<WebAddress> getAddressSet() {
		return addressSet;
	}
	public void setAddressSet(Set<WebAddress> addressSet) {
		this.addressSet = addressSet;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", addressSet=" + addressSet + "]";
	}
	
	
	
	
  }
