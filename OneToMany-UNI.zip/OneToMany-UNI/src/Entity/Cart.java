package Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Cart {
	
	@Id
	@Column
	int cartId;
	
	@Column(length=20)
	String cName;
	
	@OneToMany(cascade={CascadeType.ALL})
	@JoinTable(name="items_cart",joinColumns=@JoinColumn(name="cartId"),inverseJoinColumns=@JoinColumn(name="itemId"))
	Set<Item> itemSet=new HashSet<>();

	public Cart() {
		
	}

	public Cart(int cartId, String cName, Set<Item> itemSet) {
		super();
		this.cartId = cartId;
		this.cName = cName;
		this.itemSet = itemSet;
	}

	public Cart(int cartId, String cName) {
		super();
		this.cartId = cartId;
		this.cName = cName;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Set<Item> getItemSet() {
		return itemSet;
	}

	public void setItemSet(Set<Item> itemSet) {
		this.itemSet = itemSet;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", cName=" + cName + ", itemSet=" + itemSet + "]";
	}
	
	
	
	
	

}
