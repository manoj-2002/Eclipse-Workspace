package Main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.Cart;
import Entity.Item;


public class DeleteItem {

	public static void main(String[] args) {
		
SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Cart.class).addAnnotatedClass(Item.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Cart c1 = (Cart)session.get(Cart.class, 2);
		session.delete(c1);
		
	
		session.getTransaction().commit();
		System.out.println("object is deleted");

	}

}
