package threads;

class Normal extends Thread{
	
	public void run(){
		
		for(char i='a';i<'z';i++){
			System.out.println("Normal"+i);
		}
	}
}
	
	class Reverse extends Thread{
		
		public void run(){
			
			for (int j=10;j>0;j--){
				System.out.println("Reverse"+j);
			}
		}
	}
	
	public  class LabThread{
		
		public static void main(String args[]) throws InterruptedException{
			
			Normal n=new Normal();
			Reverse r=new Reverse();
			n.start();
			//n.join();
			r.start();
			
		}
	}
