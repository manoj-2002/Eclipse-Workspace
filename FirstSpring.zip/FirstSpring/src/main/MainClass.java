package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import entity.Employee;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("after main");
		ApplicationContext actx=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("before getBean");
		Employee emp=(Employee)actx.getBean("empBean");
		System.out.println("after getBean");
		System.out.println("eId : "+emp.geteId());
		System.out.println("name : "+emp.getName());
		System.out.println("fees : "+emp.getSalary());
		

	}

}
