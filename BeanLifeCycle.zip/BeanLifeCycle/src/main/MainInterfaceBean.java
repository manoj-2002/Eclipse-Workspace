package main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import bean.InterfaceBean;

public class MainInterfaceBean {

	public static void main(String[] args) {
		AbstractApplicationContext ac=new ClassPathXmlApplicationContext("interfaceBeans.xml");
		InterfaceBean fb=(InterfaceBean)ac.getBean("iBean");
		System.out.println("bId : "+fb.getbId());
		System.out.println("bId : "+fb.getbName());
		ac.registerShutdownHook();
	}

}
