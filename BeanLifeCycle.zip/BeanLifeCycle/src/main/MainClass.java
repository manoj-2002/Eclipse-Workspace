package main;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.FirstBean;

public class MainClass {

	public static void main(String args[]){
		AbstractApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		FirstBean fb=(FirstBean)ac.getBean("fBean");
		System.out.println("bId : "+fb.getbId());
		System.out.println("bId : "+fb.getbName());
		ac.registerShutdownHook();
	}
}
