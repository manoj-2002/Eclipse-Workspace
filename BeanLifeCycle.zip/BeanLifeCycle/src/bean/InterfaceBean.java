package bean;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class InterfaceBean implements InitializingBean,DisposableBean{
	
	int bId;
	String bName;

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("from properties set");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("form destroy");
	}

	public InterfaceBean() {
	
	}

	public int getbId() {
		return bId;
	}

	public void setbId(int bId) {
		this.bId = bId;
	}

	public String getbName() {
		return bName;
	}

	public void setbName(String bName) {
		this.bName = bName;
	}
	
	
	
}
