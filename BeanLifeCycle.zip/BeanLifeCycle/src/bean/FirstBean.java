package bean;

public class FirstBean {

	int bId;
	String bName;
	public FirstBean() {
		
	}
	public void init(){
		System.out.println("from init");
	}
	public void destroy(){
		System.out.println("from destroy");
	}
	
	public int getbId() {
		return bId;
	}
	public void setbId(int bId) {
		this.bId = bId;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	
	
	
}
