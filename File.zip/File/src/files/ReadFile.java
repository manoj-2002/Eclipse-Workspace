package files;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

	public class ReadFile {
		
		public static void main(String args[]) throws FileNotFoundException{
			 
			//Scanner sc=new Scanner(System.in);
			
			File file=new File("C:\\Users\\jagu.srisaimanoj\\Desktop\\MyFile.txt");
			
			Scanner sc=new Scanner(file);
			while (sc.hasNextLine()) {
			      System.out.println(sc.nextLine()); 
			}
		}
			
	}
