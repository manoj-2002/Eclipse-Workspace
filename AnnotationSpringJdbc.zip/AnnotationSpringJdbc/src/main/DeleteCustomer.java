package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import model.Customer;
import configuration.CustomerConfiguration;
import dao.CustomerDao;

public class DeleteCustomer {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(CustomerConfiguration.class);
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		
	    Customer c=new Customer();
	    c.setcId(1);
	    int status=cd.deleteCustomer(c);
	    System.out.println(status);

	}

}
