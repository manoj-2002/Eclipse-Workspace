package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import model.Customer;
import configuration.CustomerConfiguration;
import dao.CustomerDao;

public class SaveCustomer {
	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(CustomerConfiguration.class);
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		
		int count=cd.saveCustomer(new Customer(1,"manoj","kakinada"));
		System.out.println(count);
	}
}
