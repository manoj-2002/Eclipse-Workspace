package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import model.Customer;
import configuration.CustomerConfiguration;
import dao.CustomerDao;

public class UpdateCustomer {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(CustomerConfiguration.class);
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		
		int count=cd.updateCustomer(new Customer(1,"manoj","vizag"));
		System.out.println(count);
	}

}
