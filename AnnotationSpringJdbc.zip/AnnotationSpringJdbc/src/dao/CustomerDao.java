package dao;

import org.springframework.jdbc.core.JdbcTemplate;

import model.Customer;

public class CustomerDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveCustomer(Customer c){
		String query="insert into customer1 values("+c.getcId()+",'"+c.getcName()+"','"+c.getCity()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateCustomer(Customer c){
		String query="update customer1 set City="+c.getCity()+" where cId="+c.getcId()+"" ;
		return jdbcTemplate.update(query);
	}
	
	public int deleteCustomer(Customer c){
		String query="delete customer1 where cId="+c.getcId()+"";
		return jdbcTemplate.update(query);
	}
	

}