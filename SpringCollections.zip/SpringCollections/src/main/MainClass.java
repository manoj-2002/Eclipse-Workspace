package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.ListEmployee;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("listBeans.xml");
		ListEmployee le=(ListEmployee)ac.getBean("empBean");
		System.out.println("eId : "+le.geteId());
		System.out.println("eId : "+le.geteName());
		System.out.println("eId : "+le.getSalary());
		System.out.println("eId : "+le.getAddress());
	}

}
