package project_servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/checkinservlet")
public class checkinservlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String roomno = request.getParameter("room no");
        String fullname= request.getParameter("full name");
        String age = request.getParameter("age");
        String mobileno = request.getParameter("mobile number");
        String payment = request.getParameter("payment"); 
        try {
            
            // loading drivers for oracle
            Class.forName("oracle.jdbc.driver.OracleDriver");
           // System.out.println("1");
            //creating connection with the database 
            Connection con = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:XE","system","system");

            //System.out.println("2");

            PreparedStatement ps = con.prepareStatement
                        ("insert into checkin values(?,?,?,?,?)");

 

            ps.setString(1, roomno);
            ps.setString(2, fullname);
            ps.setString(3, age);
            ps.setString(4, mobileno);
            ps.setString(5, payment);
           
            int i = ps.executeUpdate();
            
            if(i > 0) {
            	HttpSession hs = request.getSession();
            	hs.setAttribute("roomno",1);
            	hs.setAttribute("fullname",2);
            	hs.setAttribute("age",3);
            	hs.setAttribute("mobileno",4);
            	hs.setAttribute("payment",5);
            	
                pw.println("<marquee><h3>You are sucessfully checked in<h3></marquee>");
               RequestDispatcher rs = request.getRequestDispatcher("list.html");
               rs.include(request, response);
            }
            else{
            	pw.print("<marquee><h4>invalid details<h4><marquee>");
            	//RequestDispatcher rs = request.getRequestDispatcher("check in.html");
               // rs.include(request, response);
            }
        }
        catch(Exception se) {
            se.printStackTrace();
        }
    
    }

       
	}

