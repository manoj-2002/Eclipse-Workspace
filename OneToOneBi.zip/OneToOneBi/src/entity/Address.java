package entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bi_address")
public class Address {
	
	@Id
	@Column
	int id;
	
	@Column
	int hno;
	
	@Column(length=20)
	String street;
	
	@Column(length=20)
	String pin;
	
	@OneToOne(mappedBy="address", cascade= {CascadeType.ALL})
	Employee employee;

	public Address() {
	
	}

	public Address(int id, int hno, String street, String pin) {
		super();
		this.id = id;
		this.hno = hno;
		this.street = street;
		this.pin = pin;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}
	
	

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", hno=" + hno + ", street=" + street + ", pin=" + pin + "]";
	}
	
	
	

}
