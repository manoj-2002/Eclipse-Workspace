package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Address;
import entity.Employee;

public class DeleteEmployeeBi {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).addAnnotatedClass(Address.class).buildSessionFactory();
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Address e1 = (Address)session.get(Address.class, 1);
		session.delete(e1);
		
	
		session.getTransaction().commit();
		System.out.println("object is deleted");
	}

}
