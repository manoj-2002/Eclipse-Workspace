package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity

public class worker {
		    @Id
		    @Column
		    int wid;
		    @Column(length=15)
		    String wname;
		    @Column
		    int age;
		    @Column
		    @Transient
		    String city;
			public worker() {
		
			}
			public worker(int wid, String wname, int age, String city) {
				super();
				this.wid = wid;
				this.wname = wname;
				this.age = age;
				this.city = city;
			}
			public int getWid() {
				return wid;
			}
			public void setWid(int wid) {
				this.wid = wid;
			}
			public String getWname() {
				return wname;
			}
			public void setWname(String wname) {
				this.wname = wname;
			}
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}
			public String getCity() {
				return city;
			}
			public void setCity(String city) {
				this.city = city;
			}
			@Override
			public String toString() {
				return "worker [wid=" + wid + ", wname=" + wname + ", age=" + age + ", city=" + city + "]";
			}
		    
			
		    
		     
		   
}
