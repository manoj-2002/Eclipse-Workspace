package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_employee")
public class employee {
	
	@Id
	@Column(name="emp_id")
	int eno;
	@Column(name="emp_name",length=15)
	String ename;
	@Column(name="salary")
	int salary;
	@Column(name="city",length=15)
	String city;
	public employee() {
	
	}
	public employee(int eno, String ename, int salary, String city) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.salary = salary;
		this.city = city;
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "employee [eno=" + eno + ", ename=" + ename + ", salary=" + salary + ", city=" + city + "]";
	}
	
	
	
	
	
	
	
	
	

}
