package entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
public class student {

	
	@Id
	@Column(name="s_id",length=20)
	 int sid;
	
	@Column(name="s_name",length=20)
	 String sname;
	
	@Temporal(TemporalType.DATE)
	@Column(name="doj")
	 Date doj;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="dol")
	 Date dol;
	

	public student() {

	}

	public student(int sid, String sname, Date doj, Date dol) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.doj = doj;
		this.dol = dol;
		
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	public Date getDol() {
		return dol;
	}

	public void setDol(Date dol) {
		this.dol = dol;
	}

	@Override
	public String toString() {
		return "student [sid=" + sid + ", sname=" + sname + ", doj=" + doj + ", dol=" + dol + "]";
	}
	
	


	
	
	
	
	
	
}