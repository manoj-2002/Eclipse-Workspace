package main;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.employee;
import entity.newemployee;

public class insertandselecthql {

	public static void main(String[] args) {
	
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).addAnnotatedClass(newemployee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		String hql = "insert into newemployee(eid, ename)"
		        + " select eno, ename from employee";
		Query query = session.createQuery(hql);
		int rowsAffected = query.executeUpdate();
		if (rowsAffected > 0) {
		    System.out.println(rowsAffected + "(s) were inserted");
		}
		session.getTransaction().commit();
	}

}
