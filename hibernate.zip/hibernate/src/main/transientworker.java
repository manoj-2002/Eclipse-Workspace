package main;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import entity.worker;
public class transientworker {

	public static void main(String args[]){
		
		 SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(worker.class).buildSessionFactory();
		
		 Session session=factory.getCurrentSession();
		 worker w1=new worker(1,"manoj",18,"kakinda");
		 worker w2=new worker(2,"padma sai",18,"bhimavaram");
		 worker w3=new worker(3,"suresh",18,"bhimavaram");
		 session.beginTransaction();
		 session.save(w1);
		 session.save(w2);
		 session.save(w3);
		 session.getTransaction().commit();
		 System.out.println("worker objects are persisted");
	}
}
