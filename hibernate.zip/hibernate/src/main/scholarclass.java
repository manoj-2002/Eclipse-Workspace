package main;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import entity.scholar;
public class scholarclass {

	
	 public static void main(String[] args) {
	      
	        //Creating SessionFactory object
	        SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(scholar.class).buildSessionFactory();
	        
	        /* Configuration config=new Configuration();
	         * config.configure("hibernate.cfg.xml");
	         * config.addAnnotatedClass(Scholar.class);
	         * SessionFactory factory=config.buildSessionFactory();         
	         */
	        
	        //create Session object using SessionFactory object
	        Session session=factory.getCurrentSession();
	        scholar s1=new scholar(1,"manoj","Testing","Delhi");
	        scholar s2=new scholar(2,"suresh","Testing","Chennai");
	        scholar s3=new scholar(3,"padma sai","Testing","Delhi");
	        
	        session.beginTransaction();
	        session.save(s1);
	        session.save(s2);
	        session.save(s3);
	        session.getTransaction().commit();
	        
	        System.out.println("Scholar Objects are persisted");
	    }
}
