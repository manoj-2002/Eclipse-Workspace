package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	/*
	@RequestMapping("/message.spring")
	public ModelAndView getRequest(){
		
		ModelAndView m=new ModelAndView("greeting","msg","hello good afternoon");
		return m;
	}
	*/
	@RequestMapping("/message.spring")
	public ModelAndView processRequest(@RequestParam("name") String name){
		
		ModelAndView m=new ModelAndView("greeting","name",name);
		return m;
	}
	
	
}