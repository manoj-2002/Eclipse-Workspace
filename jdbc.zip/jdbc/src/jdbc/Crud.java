package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Crud {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		
		if(con!=null){
			
			System.out.println("connected");
			Statement stmt = con.createStatement();
			stmt.executeUpdate("create table practice(pid number,ptopic varchar2(30),ptype varchar2(30))");
			System.out.println("table created");
			
			stmt.executeUpdate("insert into practice values(1,'jdbc','lab')");
			System.out.println("first row inserted");
			
			stmt.executeUpdate("insert into practice values(2,'servlets','lab')");
			System.out.println("second row inserted");
			
			stmt.executeUpdate("insert into practice values(3,'jsp','lab')");
			System.out.println("third row inserted");
			
			stmt.executeUpdate("update practice set ptype='mcq' where pid=2");
			System.out.println("row updated");
			
			stmt.executeUpdate("delete practice where pid=3");
			System.out.println("row deleted");
			
			
			
			
		}
	}

}
