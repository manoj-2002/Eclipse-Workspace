package jdbc;
import java.sql.*;
public class Jdbc {
	public static void main(String args[])throws ClassNotFoundException, SQLException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection s = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		if(s!=null){
			System.out.println("connected");
			Statement a = s.createStatement();
			a.executeUpdate("insert into employee values('suresh')");
			s.commit();
			s.close();
		}
		else{
			System.out.println("not connected");
		}
		
	}

}
