package Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class BiItem {
	
	@Id
	@Column
	int itemId;
	
	@Column(length=20)
	String itemName;
	
	@Column
	double price;
	
	@ManyToOne(cascade={CascadeType.ALL})
	BiCart cart;

	public BiItem() {
		
	}

	public BiItem(int itemId, String itemName, double price) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
	}
	
	

	public BiItem(int itemId, String itemName, double price, BiCart cart) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.cart = cart;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

	public BiCart getCart() {
		return cart;
	}

	public void setCart(BiCart cart) {
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + "]";
	}
	
	
	
	
	

}
