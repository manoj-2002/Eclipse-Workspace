package Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class BiCart {
	
	@Id
	@Column
	int cartId;
	
	@Column(length=20)
	String cName;
	
	@OneToMany(cascade={CascadeType.ALL})
	@JoinTable(name="bi_items_cart",joinColumns=@JoinColumn(name="cartId"),inverseJoinColumns=@JoinColumn(name="itemId"))
	Set<BiItem> itemSet=new HashSet<>();

	public BiCart() {
		
	}

	public BiCart(int cartId, String cName, Set<BiItem> itemSet) {
		super();
		this.cartId = cartId;
		this.cName = cName;
		this.itemSet = itemSet;
	}

	public BiCart(int cartId, String cName) {
		super();
		this.cartId = cartId;
		this.cName = cName;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public Set<BiItem> getItemSet() {
		return itemSet;
	}

	public void setItemSet(Set<BiItem> itemSet) {
		this.itemSet = itemSet;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", cName=" + cName + ", itemSet=" + itemSet + "]";
	}
	
	
	
	
	

}
