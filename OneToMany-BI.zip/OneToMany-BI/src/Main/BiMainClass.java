package Main;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.*;


public class BiMainClass {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(BiCart.class).addAnnotatedClass(BiItem.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		BiCart c1=new BiCart(1,"manoj");
		
		BiItem i1=new BiItem(1,"realme 7",14000);
		BiItem i2=new BiItem(2,"realme buds 2",600);
		BiItem i3=new BiItem(3,"charger",800);
		
		Set<BiItem> iSet=new HashSet<>();
		iSet.add(i1);
		iSet.add(i2);
		iSet.add(i3);
		c1.setItemSet(iSet);
		
		i1.setCart(c1);
		i2.setCart(c1);
		i3.setCart(c1);
	
		
		session.save(i1);
		session.save(i2);
		session.save(i3);
		session.getTransaction().commit();
		
		System.out.println("object successfully persisted");
	}

}
