package entity;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Car {
	
	@Id
	@Column
	String carname;
	@Column
	Blob image;
	public Car() {
		
	}
	public Car(String carname, Blob image) {
		super();
		this.carname = carname;
		this.image = image;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Car [carname=" + carname + ", image=" + image + "]";
	}
	
	
	
	

}
