package main;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Car;

public class RetrieveImage {

	public static void main(String[] args) {
		
		  SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Car.class).buildSessionFactory();
	        Session session=factory.getCurrentSession();
	        session.beginTransaction();
	        
	        Object obj = session.load(Car.class, "ferrari");
	        Car c = (Car)obj;
	        Blob blb = c.getImage();
	        try {
	            InputStream is = blb.getBinaryStream();
	            FileOutputStream fos= new FileOutputStream("C:\\Users\\jagu.srisaimanoj\\Desktop");
	            int k;
	            while((k=is.read())!=-1){
	                fos.write(k);
	            }
	            System.out.println("photo retrived successfully");
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
}

