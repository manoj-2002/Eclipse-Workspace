package main;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.*;


public class MainClass {

	public static void main(String[] args) {
		
SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Product.class).addAnnotatedClass(Distributor.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Distributor d1=new Distributor(2,"padma sai");
		Product p1=new Product(1,"iphone 11pro",110000);
		Product p2=new Product(2,"samsung ac",40000);
		//Product p3=new Product(3,"lg washing machine",40000);
		
		Set<Product> pSet=new HashSet<>();
		pSet.add(p1);
		pSet.add(p2);
		//pSet.add(p3);
		d1.setProductSet(pSet);
		
		session.save(d1);
		session.getTransaction().commit();
		System.out.println("object successfully persisted");

	}

}
