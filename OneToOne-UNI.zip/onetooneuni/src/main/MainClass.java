package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.*;

public class MainClass {

	public static void main(String[] args) {
	

		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).addAnnotatedClass(Address.class).buildSessionFactory();
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		Address a1 = new Address(5,132,"abcd street","54321");
		Employee e1 = new Employee(5,"muneer",30000);
		e1.setAddress(a1);
		
		session.save(e1);
		session.getTransaction().commit();
		System.out.println("object is successfully persisted");
	}

}
