package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import bean.EmployeeBean;
import configuration.EmployeeConfiguration;

public class EmpMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(EmployeeConfiguration.class);
		EmployeeBean eb=(EmployeeBean)ac.getBean("empBean");
		eb.seteId(1);
		eb.seteName("manoj");
		eb.setSalary(100000);
		System.out.println("eId : "+eb.geteId());
		System.out.println("eId : "+eb.geteName());
		System.out.println("eId : "+eb.getSalary());

	}

}
