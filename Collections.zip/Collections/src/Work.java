import java.util.ArrayList;
import java.util.List;
public class Work{
    
    String group_no;
    String seminar_room_no;
   ArrayList<String> list_participants = new ArrayList<String>();
    
    public Work() {
        // TODO Auto-generated constructor stub
    }
    public Work(String group_no, String seminar_room_no, ArrayList<String> list_participants) {
        super();
        this.group_no = group_no;
        this.seminar_room_no = seminar_room_no;
        this.list_participants = list_participants;
    }

    public String getGroup_no() {
        return group_no;
    }

    public void setGroup_no(String group_no) {
        this.group_no = group_no;
    }

    public String getSeminar_room_no() {
        return seminar_room_no;
    }

    public void setSeminar_room_no(String seminar_room_no) {
        this.seminar_room_no = seminar_room_no;
    }

    public List<String> getList_participants() {
        return list_participants;
    }

    public void setList_participants(ArrayList<String> list_participants) {
        this.list_participants = list_participants;
    }

    @Override
    public String toString() {
        return "ExtemporeArrayList [group_no=" + group_no + ", seminar_room_no=" + seminar_room_no
                + ", list_participants=" + list_participants + "]";
    }
    

}