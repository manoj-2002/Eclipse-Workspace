package Lab;

class Normal extends Thread{
	
	public void run(){
		
		for(int i=1;i<10;i++){
			System.out.println("Normal"+i);
		}
	}
}
	
	class Reverse extends Thread{
		
		public void run(){
			
			for (int j=10;j>0;j--){
				System.out.println("Reverse"+j);
			}
		}
	}
	
	public  class SimpleThread{
		
		public static void main(String args[]){
			
			Normal n=new Normal();
			Reverse r=new Reverse();
			n.start();
			r.start();
			
		}
	}


/*public class SimpleThread implements Runnable{
	
	 public void run(){  
		  for(int i=1;i<5;i++){  
		   
		    System.out.println("from run"+i);  
		  }  
		 }  
		 public static void main(String args[]){  
			 SimpleThread st= new SimpleThread(); 
			 Thread t1=new Thread(st);
			 

			 for(int i=1;i<5;i++){  
				   
				    System.out.println("from start"+i);  
		 }  
			 t1.start();  
}
}
*/