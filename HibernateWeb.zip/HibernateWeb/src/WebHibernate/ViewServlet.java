package WebHibernate;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		       
		        try{
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		String hql = "from WebEmployee";
		Query query = session.createQuery(hql);
		List<WebEmployee> list = query.list();
		 
		for (WebEmployee we : list) {
		    pw.println(we.getId());
		    pw.println(we.getUsername());
		    pw.println(we.getEmail());
		    pw.println(we.getPassword());
		    pw.println(we.getCity());
		   
		    
		}
	}
		        catch(Exception ex){
		        	ex.printStackTrace();
		        }

}
}