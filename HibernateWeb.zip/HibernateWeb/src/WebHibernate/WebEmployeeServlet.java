package WebHibernate;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import WebHibernate.WebEmployeeDao;

@WebServlet("/WebEmployeeServlet")
public class WebEmployeeServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("id"));
		String username=request.getParameter("username");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String city=request.getParameter("city");
		
		HttpSession session = request.getSession(true);
        try {
            WebEmployeeDao emp = new  WebEmployeeDao();
            emp.addEmployeeDetails(id,username,email,password,city);
            response.sendRedirect("login.html");
        } catch (Exception e) {
 
            e.printStackTrace();
        }
		
		
		
	}
	
	
	
	

}
