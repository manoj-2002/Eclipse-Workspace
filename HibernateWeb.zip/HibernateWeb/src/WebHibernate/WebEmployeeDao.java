package WebHibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class WebEmployeeDao {
	
	public void addEmployeeDetails(int id,String username, String email, String password, String city){
		try{
			SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).buildSessionFactory();
			Session session=factory.getCurrentSession();
			session.beginTransaction();
			
			WebEmployee we=new WebEmployee();
			
			we.setId(id);
			we.setUsername(username);
			we.setEmail(email);
			we.setPassword(password);
			we.setCity(city);
			session.save(we);
			session.getTransaction().commit();
			System.out.println("details added");
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
	}

}
