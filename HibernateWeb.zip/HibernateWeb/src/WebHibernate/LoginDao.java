package WebHibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class LoginDao {

	public void main(String args[]){
	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).buildSessionFactory();
	Session session=factory.getCurrentSession();
	session.beginTransaction();
	
	
}
}
