package WebHibernate;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import WebHibernate.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		    
		        String email = request.getParameter("email");
		        String password=request.getParameter("password");
		       
		        try{
		            SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).buildSessionFactory();
		            Session session=factory.getCurrentSession();
		            Transaction transaction = session.beginTransaction();
		            String hql = "from WebEmployee where email like :email and password like :password";
		            Query q = session.createQuery(hql);
		            q.setParameter("email", email);
		            q.setParameter("password",password);
		         
		            List<WebEmployee> li=q.list();
		            if (li.size() >0){
		            pw.println("successfully loged in");   
		            response.sendRedirect("WebList.html");
		            
		           /* for(WebEmployee we:li){
		            	pw.println(we.getEmail());
		            	pw.println(we.getPassword());
		            }*/
		            }
		            else{
		            	pw.print("invalid login");
		            }
		            session.getTransaction().commit();
		        }
		        catch (Exception ex) {
		        ex.printStackTrace();
		      }
		        
		    }
		       
		     

		 

		}
