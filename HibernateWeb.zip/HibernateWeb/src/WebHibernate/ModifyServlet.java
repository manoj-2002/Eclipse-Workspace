package WebHibernate;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import WebHibernate.*;


@WebServlet("/ModifyServlet")
public class ModifyServlet extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		    
		        String city = request.getParameter("city");
		        int id=Integer.parseInt(request.getParameter("id"));
		       
		        try{
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		 String hql = "update WebEmployee set city = :city where id = :id";
         Query q = session.createQuery(hql);
         q.setParameter("city", city);
         q.setParameter("id",id);
      
         int rowsAffected = q.executeUpdate();
		if (rowsAffected > 0) {
		    pw.println("Updated " + rowsAffected + " rows.");
		}
		session.getTransaction().commit();
	}
		        catch(Exception ex){
		        	ex.printStackTrace();
		        }
	}
}
