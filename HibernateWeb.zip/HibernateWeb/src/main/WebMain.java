/*package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import WebHibernate.*;

public class WebMain {

	public static void main(String[] args) {
	

		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebEmployee.class).addAnnotatedClass(WebAddress.class).buildSessionFactory();
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		WebAddress a1 = new WebAddress(1,132,"rajiv street","533005");
		WebEmployee e1 = new WebEmployee(1,"manoj",60000);
		e1.setAddress(a1);
		
		//session.save(e1);
		session.getTransaction().commit();
		System.out.println("object is successfully persisted");
	}

}
*/