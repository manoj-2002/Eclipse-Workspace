package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.*;

public class MainClass {

	public static void main(String[] args) {
		
SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Address.class).addAnnotatedClass(Employee.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		 
		Employee e1 = new Employee();
		e1.setEno(3);
		e1.setEname("suresh");
		e1.setSalary(80000);
		
		Address a1 = new Address();
		a1.setId(3);
		a1.setHno(987);
		a1.setStreet("bridge street");
		a1.setPin("534197");
		
		e1.setAddress(a1);
		a1.setEmployee(e1);
		
		session.save(a1);
		session.getTransaction().commit();
		System.out.println("object successfully persisted");
		
		
		

	}

}
