package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import entity.*;

public class ConstructorMainClass {

	public static void main(String[] args) {
		
		ApplicationContext actx = new ClassPathXmlApplicationContext("beans.xml");
		Product p=(Product)actx.getBean("pBean");
		System.out.println("================");
		System.out.println("Product Details");
		System.out.println("================");
		System.out.println("pId : "+p.getpId());
		System.out.println("pName : "+p.getpName());
		System.out.println("price : "+p.getPrice());

		Distributor d=(Distributor)actx.getBean("dBean");
		System.out.println("======================");
		System.out.println("Distrubutor Details");
		System.out.println("======================");
		System.out.println("dId : "+d.getdId());
		System.out.println("dName : "+d.getdName());
		System.out.println("Product Distrubuted : "+d.getProduct().getpId()+"\t"+d.getProduct().getpName()+"\t"+d.getProduct().getPrice());
	}

}
