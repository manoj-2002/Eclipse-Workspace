package entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	
	@Id
	@Column
	int eno;
	
	@Column(length=20)
	String ename;
	
	@Column
	int salary;
	
	@OneToOne(cascade= {CascadeType.ALL})
	@JoinColumn(name="id")
	Address address;

	public Employee() {
		
	}

	public Employee(int eno, String ename, int salary, Address address) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.salary = salary;
		this.address = address;
	}
	
	

	public Employee(int eno, String ename, int salary) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.salary = salary;
	}

	public int getEno() {
		return eno;
	}

	public void setEno(int eno) {
		this.eno = eno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", salary=" + salary + ", address=" + address + "]";
	}
	
	
	
	
	
	

}
