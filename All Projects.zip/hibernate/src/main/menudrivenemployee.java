package main;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import entity.employee;


import org.hibernate.SessionFactory;

public class menudrivenemployee {
	
	static SessionFactory factory;

static{
    Configuration config = new Configuration();
    config.configure("hibernate.cfg.xml");
    config.addAnnotatedClass(employee.class);
    factory=config.buildSessionFactory();
}
	public void addEmployee(employee emp){
    Session sc = factory.getCurrentSession();
    sc.beginTransaction();
    sc.save(emp);
    sc.getTransaction().commit();
    System.out.println(" record is added");
}
	public void removeEmployee(employee emp){
    Session sc = factory.getCurrentSession();
    sc.beginTransaction();
    sc.delete(emp);
    sc.getTransaction().commit();
    System.out.println("record is deleted");
}
	public void updateEmployee(employee emp){
    Session sc = factory.getCurrentSession();
    sc.beginTransaction();
    sc.update(emp);
    sc.getTransaction().commit();
    System.out.println("record is updated");
}
	public employee read(int emp_id){
    Session sc=factory.getCurrentSession();
    sc.beginTransaction();
    employee emp=(employee)sc.get(employee.class,emp_id);
    System.out.print("request record is: "+emp);
    sc.getTransaction();
    return emp;   
}
}

