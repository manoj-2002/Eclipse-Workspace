package main;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.employee;

public class updatehql {

	public static void main(String[] args) {
		

		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		String hql = "update employee set city = :city where id = :id";
		Query query = session.createQuery(hql);
		query.setParameter("city", "vijayawada");
		query.setParameter("id", 3);

		int rowsAffected = query.executeUpdate();
		if (rowsAffected > 0) {
		    System.out.println("Updated " + rowsAffected + " rows.");
		}
		session.getTransaction().commit();
	}
}
	
