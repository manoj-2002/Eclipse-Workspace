package main;

import java.io.InputStream;
import java.util.Scanner;

import entity.employee;

public class showmenu {

	public static void main(String[] args) {
			employee emp=new employee();
			menudrivenemployee me = new menudrivenemployee();
	
			Scanner sc=new Scanner(System.in);
			while(true){
			System.out.println("1. add employee");
			System.out.println("2. remove employee");
			System.out.println("3. search employee");
			System.out.println("4. update employee");
			System.out.println("5. exit");
			
			System.out.println("enter an option: ");
			int choice = sc.nextInt();

			switch(choice){
		case 1:
			System.out.println("enter the empolyee id: ");
            emp.setEno(sc.nextInt());
            System.out.println("enter the empolyee name: ");
            sc.nextLine();
            emp.setEname(sc.nextLine());
            System.out.println("enter the empolyee salary: ");
            emp.setSalary(sc.nextInt());
            System.out.println("enter the empolyee city: ");
            sc.nextLine();
            emp.setCity(sc.nextLine());
            me.addEmployee(emp);
            break;
        case 2:
            System.out.println("Enter the id");
            emp.setEno(sc.nextInt());
            emp=(employee)me.read(emp.getEno());
            me.removeEmployee(emp);
            break;
        case 3:
        	System.out.println("enter the employee id: ");
        	emp.setEno(sc.nextInt());
        	emp=(employee)me.read(emp.getEno());
        	System.out.println("record found  "+emp);
        	break;
        case 4:
        	System.out.println("enter the employee id: ");
        	emp.setEno(sc.nextInt());
        	sc.nextLine();
        	System.out.println("enter the empolyee name: ");
            emp.setEname(sc.nextLine());
            me.updateEmployee(emp);
            break;
		 case 5:
        	break;
        
				
	}
	}
}
}
