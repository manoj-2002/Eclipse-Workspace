package main;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.employee;

public class searchhql {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		String hql = "from employee where ename like :name ";
		System.out.println("enter name to search: ");
		String ename = sc.next();
		Query query = session.createQuery(hql);
		query.setParameter("name", "%" + ename +"%");
		
		List<employee> list = query.list();
		
		for(employee emp:list){
			
			System.out.println(emp.getEname());
		}
		session.getTransaction().commit();
		sc.close();
		
	}
		
	}

