package main;

import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.employee;

public class deletehql {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		String hql = "delete from employee where id = :eno";
		Query query = session.createQuery(hql);
		query.setParameter("eno", 4);

		int rowsAffected = query.executeUpdate();
		if (rowsAffected > 0) {
		    System.out.println("Updated " + rowsAffected + " rows.");
		}
		session.getTransaction().commit();
	}

}
