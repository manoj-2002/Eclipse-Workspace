package main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.employee;

public class groupbyhql {

	public static void main(String args[]){
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		String hql = "select sum(e.salary), e.eno.name from employee e group by eno";
        Query query = session.createQuery(hql);
        List<Object[]> listResult = query.list();
        
        for (Object[] aRow : listResult) {
            Double sum = (Double) aRow[0];
           String salary = (String) aRow[1];
           System.out.println(salary + " - " + sum);
        }
	}
}
