package main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import entity.employee;


public class listhql {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();

		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		String hql = "from employee";
		Query query = session.createQuery(hql);
		List<employee> list = query.list();
		 
		for (employee emp : list) {
		    System.out.println(emp.getEname());
		}
		session.getTransaction().commit();
	}

}
