package main;

import java.sql.Timestamp;
import java.util.Date;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.student;

public class temporalstudent {
	
	public static void main(String args[]){

	SessionFactory factory=new Configuration()
            .configure("hibernate.cfg.xml")
            .addAnnotatedClass(student.class)
            .buildSessionFactory();
	
  Session session=factory.getCurrentSession();
  student std=new student(1,"manoj",new Date(),new Date());
  session.beginTransaction();
  session.save(std);
  session.getTransaction().commit();
  System.out.println("transaction completed");
	
}
}
