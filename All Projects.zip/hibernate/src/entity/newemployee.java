package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class newemployee {
	
	@Id
	@Column(name="emp_id")
	int eid;
	@Column(name="emp_name",length=15)
	String ename;
	public newemployee() {
		
	}
	public newemployee(int eid, String ename) {
		super();
		this.eid = eid;
		this.ename = ename;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	@Override
	public String toString() {
		return "newemployee [eid=" + eid + ", ename=" + ename + "]";
	}
	
	
	
	
	
}
