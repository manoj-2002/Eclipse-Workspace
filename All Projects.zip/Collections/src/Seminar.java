import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
 class Demo{
    
    String group_no;
    String seminar_room_no;
   ArrayList<String> list_participants = new ArrayList<String>();
    
    public Demo() {
        // TODO Auto-generated constructor stub
    }

    public Demo(String group_no, String seminar_room_no, ArrayList<String> list_participants) {
        super();
        this.group_no = group_no;
        this.seminar_room_no = seminar_room_no;
        this.list_participants = list_participants;
    }

    public String getGroup_no() {
        return group_no;
    }

    public void setGroup_no(String group_no) {
        this.group_no = group_no;
    }

    public String getSeminar_room_no() {
        return seminar_room_no;
    }

    public void setSeminar_room_no(String seminar_room_no) {
        this.seminar_room_no = seminar_room_no;
    }

    public List<String> getList_participants() {
        return list_participants;
    }

    public void setList_participants(ArrayList<String> list_participants) {
        this.list_participants = list_participants;
    }

    @Override
    public String toString() {
        return "ExtemporeArrayList [group_no=" + group_no + ", seminar_room_no=" + seminar_room_no
                + ", list_participants=" + list_participants + "]";
    }
   

}
public class Seminar {

        public static void main(String[] args) {
            // TODO Auto-generated method stub
try{
            ArrayList<String>list_participants = new ArrayList<String>();
            list_participants.add("Manoj");
            list_participants.add("padma sai");
            list_participants.add("suresh");
            list_participants.add("hemanth");
            list_participants.add("vardhan");
            list_participants.add("banti");
            
            System.out.println("Before sorting = "+list_participants);
            
            Collections.sort(list_participants);
            System.out.println("After sorting = "+list_participants);
            
            
            ArrayList<String> list_participants1 = new ArrayList<String>();
            ArrayList<String> list_participants2 = new ArrayList<String>();
            
            list_participants1 = (ArrayList<String>) list_participants.subList(0, 3);
            list_participants2 = (ArrayList<String>) list_participants.subList(3, 6);
            
            System.out.println("After split List1"+list_participants1);        
            System.out.println("After split List2"+list_participants2);

           Demo ext_arr_list1 = new Demo("Group 1", "Seminar Room 1", list_participants1);
           Demo ext_arr_list2 = new Demo("Group 2", "Seminar Room 2", list_participants2);
            
            List<Demo> ext_final_list = new ArrayList<Demo>();
            ext_final_list.add(ext_arr_list1);
            ext_final_list.add(ext_arr_list2);
 
            System.out.println("****Final List****");
            for (Iterator<Demo> iterator = ext_final_list.iterator(); iterator.hasNext();) {
                Demo extemporeArrayList = (Demo) iterator.next();
                System.out.println(extemporeArrayList.getGroup_no()+" : "+extemporeArrayList.getSeminar_room_no());
                System.out.println(extemporeArrayList.getList_participants());
            }
}
            catch(java.lang.ClassCastException e){
                System.out.println("process finished");
            }

        }
}