package Lab;

import java.util.*;

class Collection{
	
	int id;
	String name;
	public Collection(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Collection [id=" + id + ", name=" + name + "]";
	}

	public static void sort(List<Collection> cList) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
	public class CollectionsLab{
		
		public static void main(String args[]){
			
			List<Collection> cList=new ArrayList<>();
			Collection c1=new Collection(1,"manoj");
			Collection c2=new Collection(2,"sravan");
			
			cList.add(c1);
			cList.add(c2);
		
			//System.out.println(cList);
			Collection.sort(cList);
			
			
			
	}
	}




