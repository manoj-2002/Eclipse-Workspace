package Main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.*;

public class UpdateItem {

	public static void main(String[] args) {
		
		 SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Cart.class).addAnnotatedClass(Item.class).buildSessionFactory();
	        Session session=factory.getCurrentSession();
	        session.beginTransaction();
	        
	        Item i1=(Item)session.get(Item.class,3);
	        
	        i1.setItemName("realme charger");
	        i1.setPrice(1000);
	        
	        session.update(i1);
	        session.getTransaction().commit();
	        System.out.println("object updated");

	}

}
