package Main;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.Cart;
import Entity.Item;

public class MainClass {

	public static void main(String[] args) {
		
SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Cart.class).addAnnotatedClass(Item.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		Cart c1=new Cart(2,"padma sai");
		
		Item i1=new Item(4,"realme 7",14000);
		Item i2=new Item(5,"realme buds 2",600);
		Item i3=new Item(6,"charger",800);
		
		Set<Item> iSet=new HashSet<>();
		iSet.add(i1);
		iSet.add(i2);
		iSet.add(i3);
		c1.setItemSet(iSet);
		
		session.save(c1);
		session.getTransaction().commit();
		
		System.out.println("object successfully persisted");
		
	}

}
