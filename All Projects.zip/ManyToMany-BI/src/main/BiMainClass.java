package main;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.BiDistributor;
import entity.BiProduct;


public class BiMainClass {

	public static void main(String[] args) {
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(BiDistributor.class).addAnnotatedClass(BiProduct.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		
		BiDistributor d1=new BiDistributor(1,"manoj");
		BiProduct p1=new BiProduct(1,"iphone 11pro",110000);
		BiProduct p2=new BiProduct(2,"samsung ac",40000);
		BiProduct p3=new BiProduct(3,"lg washing machine",40000);
		
		List<BiProduct> pSet=new ArrayList<>();
		pSet.add(p1);
		pSet.add(p2);
		pSet.add(p3);
		d1.setProductSet(pSet);
		
		p1.setDistributor(d1);
		p2.setDistributor(d1);
		p3.setDistributor(d1);
		
		session.save(p1);
		session.save(p2);
		session.save(p3);
		
		
		session.getTransaction().commit();
		System.out.print("object successfully persisted");
		
	}

}
