package entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class BiProduct {
	
	@Id
	@Column
	int pId;
	
	@Column(length=20)
	String pName;
	
	@Column
	double price;
	
	@ManyToMany(cascade= {CascadeType.ALL})
    BiDistributor distributor;

	public BiProduct() {
		
	}

	public BiProduct(int pId, String pName, double price) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.price = price;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	

	public BiDistributor getDistributor() {
		return distributor;
	}

	public void setDistributor(BiDistributor distributor) {
		this.distributor = distributor;
	}

	@Override
	public String toString() {
		return "Product [pId=" + pId + ", pName=" + pName + ", price=" + price + "]";
	}
	
	
	
	
	
	

}
