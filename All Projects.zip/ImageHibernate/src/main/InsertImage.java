package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Car;

public class InsertImage {

	public static void main(String[] args) throws IOException {
		
		  SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Car.class).buildSessionFactory();
	        Session session=factory.getCurrentSession();
	        session.beginTransaction();
	        File file = new File("C:\\Users\\jagu.srisaimanoj\\Desktop\\ferrari.jfif");
	        int length = (int)file.length();
	        byte b[] = new byte[length];
	        FileInputStream f = new FileInputStream(file);
	        f.read(b);
	        
	        Blob photo = Hibernate.getLobCreator(session).createBlob(b);
	        Car c = new Car();
	        c.setCarname("ferrari");
	        c.setImage(photo);
	        
	        session.saveOrUpdate(c);
	        session.getTransaction().commit();
	        System.out.println("successfully stored an image");
	    }
	}
	 
	


