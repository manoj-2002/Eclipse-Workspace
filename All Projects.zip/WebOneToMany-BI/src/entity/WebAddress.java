package entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="task_address")
public class WebAddress 
 {
    @Id
    @Column
	int aId;
    @Column(length=20)
    String streetName;
    @Column(length=20)
    String city;
    
    @ManyToOne(cascade= {CascadeType.ALL})
    WebEmployee employee;

	public WebAddress() {
		
	}

	public WebAddress(int aId, String streetName, String city) {
		super();
		this.aId = aId;
		this.streetName = streetName;
		this.city = city;
	}

	public WebAddress(int aId, String streetName, String city, WebEmployee employee) {
		super();
		this.aId = aId;
		this.streetName = streetName;
		this.city = city;
		this.employee = employee;
	}

	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public WebEmployee getEmployee() {
		return employee;
	}

	public void setEmployee(WebEmployee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Address [aId=" + aId + ", streetName=" + streetName + ", city=" + city + ", employee=" + employee + "]";
	}
	 
	
    
    
    
 }
