package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.WebAddress;
import entity.WebEmployee;


@WebServlet("/MainClass")
public class MainClass extends HttpServlet {

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(WebAddress.class).addAnnotatedClass(WebEmployee.class).buildSessionFactory();
		
		
		Session session=factory.getCurrentSession();
		session.beginTransaction();
		 
		WebEmployee e1=new WebEmployee(1,"Manoj");
		WebAddress a1=new WebAddress(1,"rajiv street","kakinada");
		WebAddress a2=new WebAddress(2,"abcd street","kakinada");
		WebAddress a3=new WebAddress(2,"srmt colony","kakinada");
		
		Set<WebAddress> aSet=new HashSet<>();
		aSet.add(a1);
		aSet.add(a2);
		aSet.add(a3);
		
		e1.setAddressSet(aSet);
		
		a1.setEmployee(e1);
		a2.setEmployee(e1);
		a3.setEmployee(e1);
		
		session.save(a1);
		session.save(a2);
		session.save(a3);
		session.getTransaction().commit();
		pw.println("object successfully persisted");
		
	}

}
