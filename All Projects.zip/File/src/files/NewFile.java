package files;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.*;

public class NewFile {
	
	public static void main(String args[]) throws FileNotFoundException{
		 
		Scanner sc=new Scanner(System.in);
		
		File file=new File("C:\\Users\\jagu.srisaimanoj\\Desktop\\MyFile.txt");
		try{
			file.createNewFile();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		System.out.println("enter something:");
		String something =sc.nextLine();
		try{
			FileWriter fw=new FileWriter("C:\\Users\\jagu.srisaimanoj\\Desktop\\MyFile.txt",true);
			BufferedWriter bw=new BufferedWriter(fw);
			
			bw.write(something);
			bw.newLine();
			bw.close();
			fw.close();
			
			System.out.println("file is successfully created");
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
