package Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

@Entity
public class Distributor {
	
	@Id
	@Column
	int dId;
	
	@Column(length=20)
	String dName;
	
	@ManyToMany(cascade ={CascadeType.ALL})
	@JoinTable(name="product_distributor",joinColumns=@JoinColumn(name="dId"),inverseJoinColumns=@JoinColumn(name="pId"))
	Set<Product> productSet=new HashSet<>();

	public Distributor() {
		
	}

	
	public Distributor(int dId, String dName, Set<Product> productSet) {
		super();
		this.dId = dId;
		this.dName = dName;
		this.productSet = productSet;
	}


	public Distributor(int dId, String dName) {
		super();
		this.dId = dId;
		this.dName = dName;
	}

	public int getdId() {
		return dId;
	}

	public void setdId(int dId) {
		this.dId = dId;
	}

	public String getdName() {
		return dName;
	}

	public void setdName(String dName) {
		this.dName = dName;
	}


	public Set<Product> getProductSet() {
		return productSet;
	}


	public void setProductSet(Set<Product> productSet) {
		this.productSet = productSet;
	}


	@Override
	public String toString() {
		return "Distributor [dId=" + dId + ", dName=" + dName + ", productSet=" + productSet + "]";
	}

	
	
	
	
	
}
