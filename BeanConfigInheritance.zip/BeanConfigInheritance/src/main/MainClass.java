package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Employee;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		Employee eb=(Employee)ac.getBean("eBean");
		System.out.println("eId : "+eb.getId());
		System.out.println("eId : "+eb.getName());
		System.out.println("eId : "+eb.getSalary());


	}

}
