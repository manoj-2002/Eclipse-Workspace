package dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import bean.Scholar;
import mapper.ScholarExtractor;
import mapper.ScholarMapper;

public class ScholarDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveScholar(Scholar s){
		String query="insert into scholar values("+s.getsId()+",'"+s.getsName()+"','"+s.getCity()+"',"+s.getsMarks()+",'"+s.getPhone()+"')";
		return jdbcTemplate.update(query);
	}
	
	public int updateScholar(Scholar s){
		String query="update scholar set sMarks="+s.getsMarks()+" where sId="+s.getsId()+"" ;
		return jdbcTemplate.update(query);
	}
	
	public int deleteScholar(Scholar s){
		String query="delete scholar where sId="+s.getsId()+"";
		return jdbcTemplate.update(query);
	}
	
	public List<Scholar> getAllScholarRowMapper(){
		List<Scholar> lisc=jdbcTemplate.query("select * from Scholar", new ScholarMapper());
		return lisc;
	}
	
	public List<Scholar> getAllScholarExtractor(){
		List<Scholar> lisc=jdbcTemplate.query("select * from Scholar", new ScholarExtractor());
		return lisc;
	}

}
