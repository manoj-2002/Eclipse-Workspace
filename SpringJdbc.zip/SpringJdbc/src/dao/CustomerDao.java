package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import bean.Customer;
import bean.Scholar;
import mapper.CustomerExtractor;
import mapper.ScholarExtractor;

public class CustomerDao {
	private SimpleJdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(SimpleJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int saveCustomer(Customer c){
		String query="insert into customer values(?,?,?)";
		return jdbcTemplate.update(query,c.getcId(),c.getcName(),c.getCity());
	}
	
	public int updateCustomer(Customer c){
		String query="update customer set city=? where cId=?";
		return jdbcTemplate.update(query,c.getCity(),c.getcId());
		
	}
	
	public int deleteCustomer(Customer c){
		String query="delete customer where cId=?";
		return jdbcTemplate.update(query,c.getcId());
		
	}
	
	/*public List<Customer> getAllCustomerExractor(){
		List<Customer> lisc=jdbcTemplate.query("select * from Customer", new CustomerExtractor());
		return lisc;
	}
*/
	/*
	public int saveCustomer(Customer c){  
    String query="insert into customer(cid,cname,city) values(:cid,:cname,:city)"; 
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("cId : ",c.getcId());
    map.put("cName : ",c.getcName());
    map.put("City : ",c.getCity());
   return jdbcTemplate.update(query,map);
    
} 
public int updateCustomer(Customer c){  
    String query="update Customer set City = :City where cId = :cid";  
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("cId : ",c.getcId());
    map.put("cName : ",c.getcName());
    map.put("City : ",c.getCity());
   return jdbcTemplate.update(query,map);  
}*/
}
