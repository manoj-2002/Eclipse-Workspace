package bean;

public class Scholar {
	int sId;
	String sName;
	String city;
	int sMarks;
	String phone;
	public Scholar() {
		
}
	
	public Scholar(int sId) {
		super();
		this.sId = sId;
	}

	public Scholar(int sId, String sName, String city, int sMarks, String phone) {
		super();
		this.sId = sId;
		this.sName = sName;
		this.city = city;
		this.sMarks = sMarks;
		this.phone = phone;
	}
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getsMarks() {
		return sMarks;
	}
	public void setsMarks(int sMarks) {
		this.sMarks = sMarks;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Scholar [sId=" + sId + ", sName=" + sName + ", city=" + city + ", sMarks=" + sMarks + ", phone=" + phone
				+ "]";
	}
	
	
}
