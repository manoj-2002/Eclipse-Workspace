package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bean.Scholar;

public class ScholarMapper implements RowMapper<Scholar>{

	public ScholarMapper(){
		
	}
	
	public Scholar mapRow(ResultSet rs, int rownumber)throws SQLException{
		Scholar s=new Scholar();
		s.setsId(rs.getInt(1));
		s.setsName(rs.getString(2));
		s.setCity(rs.getString(3));
		s.setsMarks(rs.getInt(4));
		s.setPhone(rs.getString(5));
		return s;
	}
}