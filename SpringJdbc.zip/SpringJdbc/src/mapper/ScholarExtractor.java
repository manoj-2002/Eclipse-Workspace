package mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import bean.Scholar;

public class ScholarExtractor implements ResultSetExtractor<List<Scholar>> {
	
	

	public ScholarExtractor() {
	
	}

	@Override
	public List<Scholar> extractData(ResultSet rs) throws SQLException, DataAccessException {
		
		List<Scholar> li=new ArrayList<Scholar>();
		while(rs.next()){
			Scholar s=new Scholar();
			s.setsId(rs.getInt(1));
			s.setsName(rs.getString(2));
			s.setCity(rs.getString(3));
			s.setsMarks(rs.getInt(4));
			s.setPhone(rs.getString(5));
			li.add(s);
		}
		return li;
	}

}
