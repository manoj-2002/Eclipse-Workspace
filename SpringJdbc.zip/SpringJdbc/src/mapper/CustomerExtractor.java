package mapper;

import bean.Customer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;


public class CustomerExtractor implements ResultSetExtractor<List<Customer>>{

	public CustomerExtractor() {
	}

	@Override
	public List<Customer> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Customer c=new Customer();
		List<Customer> li=new ArrayList<Customer>();
		while(rs.next()){
			c.setcId(rs.getInt(1));
			c.setcName(rs.getString(2));
			c.setCity(rs.getString(3));
			li.add(c);
		}
		return li;
	}
	

}
