package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.*;
import dao.*;

public class MainScholar {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("scholarBeans.xml");
		ScholarDao cd=(ScholarDao)ac.getBean("schDao");
		
		int count=cd.saveScholar(new Scholar(2,"padma sai","bhimavaram", 100, "54321"));
		System.out.println(count);

	}

}
