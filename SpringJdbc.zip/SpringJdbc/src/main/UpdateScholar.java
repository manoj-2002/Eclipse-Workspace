package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Scholar;
import dao.ScholarDao;

public class UpdateScholar {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("scholarBeans.xml");
		ScholarDao cd=(ScholarDao)ac.getBean("schDao");
		
		int count=cd.updateScholar(new Scholar(1,"manoj","kakinada", 99, "987654321"));
		System.out.println(count);

	}

}
