package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Customer;
import dao.CustomerDao;

public class UpdateCustomer {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		
		int count=cd.updateCustomer(new Customer(3,"suresh","marteru"));
		System.out.println(count);

	}

}
