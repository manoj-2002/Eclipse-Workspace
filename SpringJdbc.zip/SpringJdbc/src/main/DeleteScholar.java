package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.*;
import dao.*;

public class DeleteScholar {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("scholarBeans.xml");
		ScholarDao cd=(ScholarDao)ac.getBean("schDao");
		
		
	    Scholar s=new Scholar();
	    s.setsId(1);
	    int status=cd.deleteScholar(s);
	    System.out.println(status);
	}

}
