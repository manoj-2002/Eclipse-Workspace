package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Customer;
import dao.CustomerDao;
import java.util.Scanner;

public class DeleteCustomer {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		
	    Customer c=new Customer();
	    c.setcId(4);
	    int status=cd.deleteCustomer(c);
	    System.out.println(status);
		
		/*System.out.println("Enter the id");
        c.setcId(sc.nextInt());
        c=(Customer)cd.read(c.getcId());
        cd.deleteCustomer(c);*/
		
	}
}
