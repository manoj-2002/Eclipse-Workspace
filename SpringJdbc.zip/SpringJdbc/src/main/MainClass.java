package main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Customer;
import dao.CustomerDao;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//int count=0;
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		CustomerDao cd=(CustomerDao)ac.getBean("cusDao");
		Customer c=new Customer();
		
		/*count=cd.saveCustomer(new Customer(5,"muneer","ongole"));
		count++;
		
		count=cd.saveCustomer(new Customer(2,"padma sai","bhimavaram"));
		count++;
		
		count=cd.saveCustomer(new Customer(3,"suresh","marteru"));
		count++;
		
		count=cd.saveCustomer(new Customer(4,"tube light","tenali"));
		count++;
		
		System.out.println("total rows saved are : "+count);*/

		System.out.println("enter the customer id: ");
        c.setcId(sc.nextInt());
        System.out.println("enter the customer name: ");
        sc.nextLine();
        c.setcName(sc.nextLine());
        System.out.println("enter the customer city: ");
        c.setCity(sc.nextLine());
        cd.saveCustomer(c);
        System.out.println("customer details saved");
	}
}