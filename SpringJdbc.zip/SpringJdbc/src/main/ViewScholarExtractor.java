package main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Scholar;
import dao.ScholarDao;

public class ViewScholarExtractor {

	public static void main(String[] args) {
	
		ApplicationContext ac=new ClassPathXmlApplicationContext("scholarBeans.xml");
		ScholarDao cd=(ScholarDao)ac.getBean("schDao");
		
		
		List<Scholar> li=cd.getAllScholarExtractor();
			System.out.println(li);


	}

}
