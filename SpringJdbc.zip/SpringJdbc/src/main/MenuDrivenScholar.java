package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Scholar;

import java.util.List;
import java.util.Scanner;

import dao.ScholarDao;

public class MenuDrivenScholar {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("scholarBeans.xml");
		ScholarDao cd=(ScholarDao)ac.getBean("schDao");
		
		Scanner sc=new Scanner(System.in);
		Scholar s=new Scholar();
		ScholarDao sd=new ScholarDao();
		while(true){
			System.out.println("enter your choice:");
			System.out.println("1.save scholar details");
			System.out.println("2.update scholar details");
			System.out.println("3.delete scholar details");
			System.out.println("4.to view details");
			System.out.println("5.to exit");
			
			int choice=sc.nextInt();
			
			switch(choice){
			case 1:
				  System.out.println("enter scholar id");
		          int id=sc.nextInt();
		          System.out.println("enter scholar name");
		          String name=sc.next();
		          System.out.println("enter scholar city");
		          String city=sc.next();
		          System.out.println("enter scholar marks");
		          int marks=sc.nextInt();
		          if(marks<=0&&marks>=1000){
		        	  System.out.println("plese enter valid marks");
		          }
		          marks=sc.nextInt();
		          System.out.println("enter scholar phone number");
		          String phone=sc.next();
		          cd.saveScholar(new Scholar(id,name,city, marks, phone));
		          System.out.println("scholar details successfully saved!");
		          break;
		          
			case 2:
				  System.out.println("enter scholar id");
		          int id1=sc.nextInt();
		          System.out.println("enter scholar name");
		          String name1=sc.next();
		          System.out.println("enter scholar city");
		          String city1=sc.next();
		          System.out.println("enter scholar marks");
		          int marks1=sc.nextInt();
		          if(marks1<=0&&marks1>=1000){
		        	  System.out.println("plese enter valid marks");
		          }
		          marks1=sc.nextInt();
		          System.out.println("enter scholar phone number");
		          String phone1=sc.next();
				  cd.updateScholar(new Scholar(id1, name1, city1, marks1, phone1));
				  System.out.println("scholar details updated successfully saved!");
				  break;
					
			case 3:
				 System.out.println("enter the scholar id:");
				 s.setsId(sc.nextInt());
				 cd.deleteScholar(s);
				 System.out.println("scholar details deleted!!");
			   	 break;
			   	 
			case 4:
				  List<Scholar> li=cd.getAllScholarRowMapper();
				  System.out.println(li);
				  break;
				
			case 5:
				System.out.println("you are exited"); 
				System.exit(0);
				
			default:
				System.out.println("please choose correct option!");
			}
		}
		
		
	}

}
