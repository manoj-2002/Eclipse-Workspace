package main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Customer;
import bean.Scholar;
import dao.CustomerDao;

public class ViewCustomer {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		Customer cs=(Customer)ac.getBean("cusDao");
		
		/*List<Customer> li=cs.getAllCustomerExtractor();
		System.out.println(li);*/

	}

}
